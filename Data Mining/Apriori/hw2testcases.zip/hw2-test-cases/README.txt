Please note that you should use recommended minsup for different dataset. It takes very long time for your program to run some of the dataset with small minsup.


Dataset Name :pumsb.txt , Recommended Minsup : 1300

Dataset Name : mushroom.txt , Recommended Minsup : 2000

Dataset Name: chess.txt, Recommended Minsup: 2900